# Practice-Website

Link for the website : [https://shreyb2091.github.io/Practice-Website/](https://shreyb2091.github.io/Practice-Website/)

This is the first complete website I've made.

HTML, CS and JavaScript were used to make the website.

It is a responsive website and also uses some basic PHP for sending form data to the server.
